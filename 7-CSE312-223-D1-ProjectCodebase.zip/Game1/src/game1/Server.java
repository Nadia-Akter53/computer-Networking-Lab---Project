
package game1;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

public class Server extends javax.swing.JFrame {

    
      private ServerSocket serverSocket;
    private int playerScore = 0;
    private int botScore = 0;
    private int roundsPlayed = 0;
    private int totalRounds = 5;
    private boolean running = false;

    
  public Server(int rounds) {
      this.totalRounds = rounds;
        initComponents();
        setTitle("RPS Server - Running");
        startServer(); // Auto-start when created
    }

    
    private void startServer() {
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(8888);
                running = true;
                
                while (running) {
                    try (Socket clientSocket = serverSocket.accept();
                         PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                         BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {
                        
                        out.println("Welcome to Rock-Paper-Scissors! Playing " + totalRounds + " rounds.");
                        out.println("GAMEINFO:ROUNDS:" + totalRounds);
                        
                        while (running && roundsPlayed < totalRounds) {
                            String input = in.readLine();
                            if (input == null) break;
                            
                            if (input.equalsIgnoreCase("rock") || 
                                input.equalsIgnoreCase("paper") || 
                                input.equalsIgnoreCase("scissors")) {
                                
                                String botChoice = getBotChoice();
                                String result = determineWinner(input, botChoice);
                                
                                out.println("RESULT:You chose " + input + "||Bot chose " + botChoice + "||" + result);
                                out.println("SCORE:Player:" + playerScore + "||Bot:" + botScore + 
                                          "||Round:" + (roundsPlayed+1) + "/" + totalRounds);
                            }
                        }
                        
                        String gameResult;
                        if (playerScore > botScore) {
                            gameResult = "CONGRATS YOU WON " + playerScore + "-" + botScore;
                        } else if (botScore > playerScore) {
                            gameResult = "YOU LOST " + playerScore + "-" + botScore + ", BETTER LUCK NEXT TIME";
                        } else {
                            gameResult = "IT'S A TIE! " + playerScore + "-" + botScore;
                        }
                        
                        out.println("GAMEOVER:" + gameResult);
                        resetScores();
                        
                    } catch (IOException e) {
                        if (running) {
                            System.err.println("Client error: " + e.getMessage());
                        }
                    }
                }
            } catch (IOException e) {
                System.err.println("Server error: " + e.getMessage());
            }
        }).start();
    }

    private String getBotChoice() {
        String[] choices = {"Rock", "Paper", "Scissors"};
        return choices[new Random().nextInt(3)];
    }
    
    private String determineWinner(String playerChoice, String botChoice) {
        roundsPlayed++;
        playerChoice = playerChoice.substring(0, 1).toUpperCase() + playerChoice.substring(1).toLowerCase();
        
        if (playerChoice.equals(botChoice)) {
            return "Round " + roundsPlayed + ": Tie!";
        } else if ((playerChoice.equals("Rock") && botChoice.equals("Scissors")) ||
                  (playerChoice.equals("Paper") && botChoice.equals("Rock")) ||
                  (playerChoice.equals("Scissors") && botChoice.equals("Paper"))) {
            playerScore++;
            return "Round " + roundsPlayed + ": You win!";
        } else {
            botScore++;
            return "Round " + roundsPlayed + ": Bot wins!";
        }
    }
    
    private void resetScores() {
        playerScore = 0;
        botScore = 0;
        roundsPlayed = 0;
    }

    
    
    
    
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 255, 255));

        jLabel1.setBackground(new java.awt.Color(102, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Server is Running....");

        jButton1.setBackground(new java.awt.Color(255, 204, 102));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Project/exit.png"))); // NOI18N
        jButton1.setText("Terminated ");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(153, 153, 153)
                .addComponent(jLabel1)
                .addContainerGap(78, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(106, 106, 106))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(55, 55, 55))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
setVisible(false);
 new Home().setVisible(true);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

 public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            
            new Server(5).setVisible(true);
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
