
package game1;


import java.io.*;
import java.net.*;
import javax.swing.*;

public class Player2 extends javax.swing.JFrame {
       private static final String HOST = "localhost";
    private static final int PORT = 6666;
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private boolean myTurn = false;
    private int roundsToPlay = 0;
    private int roundsPlayed = 0;
    private int player1Score = 0;
    private int player2Score = 0;
    
   public Player2() {
       initComponents();
        jButton1.setText("Rock");
        jButton2.setText("Paper");
        jButton3.setText("Scissors");
        updateDisplay("Connecting to Player 1...");
        setButtonsEnabled(false);
        connectToServer();
    }

  private void updateDisplay(String message) {
        jTextArea1.setText(message);
        // MODIFICATION: Update scoreboard
        scorearea.setText("Player 1: " + player1Score + "\nPlayer 2: " + player2Score + 
                         "\nRound: " + (roundsPlayed+1) + "/" + roundsToPlay);
    }
    
    
    // MODIFICATION: Added method to control button states
  
    private void setButtonsEnabled(boolean enabled) {
        jButton1.setEnabled(enabled);
        jButton2.setEnabled(enabled);
        jButton3.setEnabled(enabled);
    }
    
    
    
      private void connectToServer() {
        new Thread(() -> {
            try {
                socket = new Socket(HOST, PORT);
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                
                while (true) {
                    String received = in.readLine();
                    if (received != null) {
                        if (received.startsWith("ROUNDS:")) {
                            // MODIFICATION: Get round count from server
                            roundsToPlay = Integer.parseInt(received.substring(7));
                            updateDisplay("Connected! Rounds to play: " + roundsToPlay);
                        }
                        else if (received.startsWith("TURN:")) {
                            myTurn = received.endsWith("2");
                            SwingUtilities.invokeLater(() -> {
                                setButtonsEnabled(myTurn);
                                if (myTurn) {
                                    updateDisplay("Your turn! Make your choice.");
                                } else {
                                    updateDisplay("Waiting for Player 1...");
                                }
                            });
                        }
                        else if (received.startsWith("RESULT:")) {
                            // MODIFICATION: Parse result and update scores
                            String[] parts = received.substring(7).split("\\|\\|");
                            roundsPlayed = Integer.parseInt(parts[0].replace("Round ", ""));
                            
                            if (parts[3].contains("Player 1 wins")) {
                                player1Score++;
                            } else if (parts[3].contains("Player 2 wins")) {
                                player2Score++;
                            }
                            
                            SwingUtilities.invokeLater(() -> {
                                updateDisplay(received.substring(7).replace("||", "\n"));
                            });
                        }
                        // In the message handling loop:
else if (received.startsWith("GAMEOVER:")) {
    SwingUtilities.invokeLater(() -> {
        updateDisplay(received.substring(9)); // Show the message sent by Player1
        setButtonsEnabled(false);
    });
    socket.close();
    break;
}
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        scorearea = new javax.swing.JTextArea();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 204, 204));

        jTextArea1.setBackground(new java.awt.Color(255, 255, 204));
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setText("Rock");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setText("Paper");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setText("Scissor");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Player 2");

        scorearea.setBackground(new java.awt.Color(255, 255, 204));
        scorearea.setColumns(20);
        scorearea.setRows(5);
        jScrollPane2.setViewportView(scorearea);

        jButton4.setBackground(new java.awt.Color(102, 204, 255));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton4.setText("Chat");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(102, 255, 102));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton5.setText("Back");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(155, 155, 155)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 198, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(54, 54, 54))
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jButton1)
                .addGap(42, 42, 42)
                .addComponent(jButton2)
                .addGap(63, 63, 63)
                .addComponent(jButton3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addGap(26, 26, 26)
                .addComponent(jButton5)
                .addGap(17, 17, 17))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(jLabel1)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jButton4))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton5)))
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      if (myTurn) {
            out.println("PLAYER2_CHOICE:Rock");
            updateDisplay("You chose Rock. Waiting for result...");
            myTurn = false;
            setButtonsEnabled(false);
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
     if (myTurn) {
            out.println("PLAYER2_CHOICE:Paper");
            updateDisplay("You chose Paper. Waiting for result...");
            myTurn = false;
            setButtonsEnabled(false);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
 if (myTurn) {
            out.println("PLAYER2_CHOICE:Scissors");
            updateDisplay("You chose Scissors. Waiting for result...");
            myTurn = false;
            setButtonsEnabled(false);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
 if (myTurn) {
        javax.swing.SwingUtilities.invokeLater(() -> {
       // setVisible(false);
        new Client2().setVisible(true);
    });
    
    // Start Client after short delay
    new java.util.Timer().schedule(
        new java.util.TimerTask() {
            @Override
            public void run() {
                javax.swing.SwingUtilities.invokeLater(() -> {
                    setVisible(false);
                    new Client1().setVisible(true);
                });
            }
        },
        500 // 0.5 second delay
    );
 }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

setVisible(false);

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

  
    public static void main(String args[]) {
 
        java.awt.EventQueue.invokeLater(() -> {
            new Player2().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea scorearea;
    // End of variables declaration//GEN-END:variables
}
